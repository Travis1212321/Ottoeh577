<h1 align="center">【 ✯ OTTO² BOT 🥷🔥 ✰ 】</p>
<p>
        <img src= "https://raw.githubusercontent.com/StarlightsTeam/Ai-Hoshino/main/storage/img/menu.jpg">
    </p>
    <p align="center">
        <a href="#"><img title="simple-whatsapp-bot" src="https://img.shields.io/badge/-SIMPLE--WHATSAPP--BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
    </p>
    <p>
        <a href="https://github.com/StarlightsTeam"><img title="المؤلف"    src="https://img.shields.io/badge/Author-おDaniel-purple.svg?style=for-the-badge&logo=github"></a>
    </p>
    <p>
        <a href="https://github.com/StarlightsTeamollowers"><img title="المتابعون" src="https://img.shields.io/github/followers/StarlightsTeam?color=blue&style=flat-square"></a>
        <a href="https://github.com/StarlightsTeam/Ai-Hoshino/stargazers/"><img title="النجوم" src="https://img.shields.io/github/stars/StarlightsTeam/Ai-Hoshino?color=red&style=flat-square"></a>
        <a href="https://github.com/StarlightsTeam/Ai-Hoshino/network/members"><img title="التفرعات" src="http://img.shields.io/github/forks/StarlightsTeam/Ai-Hoshino?color=red&style=flat-square"></a>
        <a href="#"><img src="https://img.shields.io/badge/الصيانة-نعم-blue.svg"</a>
        <img src="https://img.shields.io/github/repo-size/StarlightsTeam/Ai-Hoshino" /> <br>
   </p>
   <p>
</h1>

---------

## <img src="https://i.pinimg.com/originals/73/69/6e/73696e022df7cd5cb3d999c6875361dd.gif" alt="المميزات" width="42" height="42"> المميزات

> البوت قيد الإنشاء، سيتم إضافة المزيد قريباً

- [x] تفاعل صوتي ونصي
- [x] إعدادات المجموعات
- [x] منع الحذف، منع الروابط، منع الكلمات العربية، وغيرها
- [x] ترحيب مخصص
- [x] دردشة ذكية (simsimi)
- [x] إنشاء ملصقات من صورة/فيديو/GIF/رابط
- [x] بوت فرعي (Jadibot)
- [x] لعبة RPG
- [x] تنزيل موسيقى وفيديو من يوتيوب
- [ ] أخرى

---------

## <img src="https://i.pinimg.com/originals/19/80/6e/19806e91932e6054965fc83b85241270.gif" alt="التواصل" width="42" height="42"> التواصل

- إذا كان لديك أي استفسار تواصل معي ฅ^•ﻌ•^ฅ

* <a href="https://wa.me/5218261000681"><img alt="واتساب" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---------

## <img src="https://static.wikia.nocookie.net/nyancat/images/d/d3/Nyan-cat.gif/revision/latest/scale-to-width-down/400?cb=20131231222500&path-prefix=es" alt="مجموعة" width="45" height="43"> مجموعة واتساب

- إذا كنت تريد تجربة البوت قبل التثبيت

* <a href="https://chat.whatsapp.com/CH3hrd4ovGHIsFjj8dWGrf"><img alt="المجموعة" src="https://img.shields.io/badge/Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---------

## إحصائيات المشروع 🔭

![github card](https://github-readme-stats.vercel.app/api/pin/?username=StarlightsTeam&repo=Ai-Hoshino&theme=chartreuse-dark)

---------

## <img src="https://raw.githubusercontent.com/vilcajoal/vilcajoal/master/assets/octocat-anime.gif" alt="جيت هاب" width="44" height="44"> إحصائيات GitHub

![github stats](https://github-readme-stats.vercel.app/api?username=StarlightsTeam&show_icons=true&theme=chartreuse-dark)
![github toplang](https://github-readme-stats.vercel.app/api/top-langs/?username=StarlightsTeam&layout=compact&theme=chartreuse-dark)

---------
<div align="center">
  <h1 align="center">محرر ومالك البوت</h1>

<a href="https://github.com/IrokzDal"><img src="https://github.com/IrokzDal.png" width="300" height="300" alt="Irokz Dal ダーク"/></a>

`© Ai OTTO² BOT_ بواسطة OTTO²✓`
</div>