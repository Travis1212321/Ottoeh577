import { areJidsSameUser } from '@whiskeysockets/baileys'

export async function before(m, { participants, conn }) {
    // إذا كانت الرسالة في مجموعة
    if (m.isGroup) {
        // جلب بيانات الدردشة من قاعدة البيانات العالمية
        let chat = global.db.data.chats[m.chat]

        // إذا خاصية "antiBot" غير مفعلة في الدردشة، نخرج بدون تنفيذ شيء
        if (!chat.antiBot) {
            return
        }

        // رقم البوت الأصلي (من قاعدة البيانات العالمية)
        let botJid = global.conn.user.jid

        // إذا رقم البوت الحالي يساوي رقم البوت الأصلي، نخرج (أي هو نفس البوت)
        if (botJid === conn.user.jid) {
            return
        } else {
            // نتحقق إذا البوت الأصلي موجود ضمن المشاركين في الجروب
            let isBotPresent = participants.some(p => areJidsSameUser(botJid, p.id))

            // إذا البوت الأصلي موجود في المجموعة
            if (isBotPresent) {
                // بعد 5 ثواني، البوت الحالي (اللي هو غير البوت الأصلي) يخرج من المجموعة
                setTimeout(async () => {
                    await this.groupLeave(m.chat)
                }, 5000)
            }
        }
    }
}