let handler = m => m

handler.before = async function (m, {conn, isAdmin, isBotAdmin, isOwner}) {
  // إذا الرسالة مش في جروب يرجع false (يرفض التنفيذ)
  if (!m.isGroup) return false
  
  // يجلب بيانات الدردشة من قاعدة البيانات العالمية
  let chat = global.db.data.chats[m.chat]
  
  // إذا البوت مسؤول، والمجموعة مفعّل فيها خيار "onlyLatinos"،
  // والمرسل مش أدمن ولا مالك الجروب
  if (isBotAdmin && chat.onlyLatinos && !isAdmin && !isOwner) {
    // قائمة البادئات الممنوعة للأرقام (ممثلة بدول غير ناطقة بالإسبانية)
    let forbidPrefixes = ["212", "265", "234", "258", "263", "93", "967", "92", "234", "91", "254", "213"]

    for (let prefix of forbidPrefixes) {
      // إذا بدأ رقم المرسل بأي من هذه البادئات
      if (m.sender.startsWith(prefix)) {
        // يرسل رسالة تنبيه للعضو
        m.reply('🚩 En este grupo solo se permite personas de habla hispana.', m.sender)
        // يطرد العضو من المجموعة
        await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        return false
      }
    }
  }
  
  // يرجع true للسماح بالتنفيذ لو ما صار شي يمنع
  return true
}

export default handler